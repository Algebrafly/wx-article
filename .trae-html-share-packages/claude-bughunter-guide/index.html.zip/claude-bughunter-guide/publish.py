# -*- coding: utf-8 -*-
import os, re, json, time
from pathlib import Path
import requests

WORK_DIR = Path(__file__).resolve().parent
BODY_FILE = WORK_DIR / "body.html"
ASSETS_DIR = WORK_DIR / "assets"

TITLE = "把 Claude 变成漏洞猎人：Claude-BugHunter 上手记"
AUTHOR = "TraeWork"
DIGEST = "85 个技能、16 个命令、6 个阶段和一道 7 问门：这个开源技能包如何把 Claude Code 变成有章法的安全测试助手。"
THUMB_NAME = "cover.png"

APPID = os.environ.get("MP_APPID", "")
APPSECRET = os.environ.get("MP_APPSECRET", "")
BASE = "https://api.weixin.qq.com/cgi-bin"
TIMEOUT = 60


def request(method, url, retries=60, **kwargs):
    kwargs.setdefault("timeout", TIMEOUT)
    last = None
    for i in range(retries):
        try:
            data = requests.request(method, url, **kwargs).json()
        except Exception as e:
            last = e
            time.sleep(2)
            continue
        code = data.get("errcode", 0)
        if code in (0, None):
            return data
        if code == 40164:
            print(f"  [40164] IP 未加白，重试 {i + 1}/{retries}")
            time.sleep(0.8)
            continue
        if code in (-1, 45009, 40001, 42001):
            print(f"  [{code}] 瞬时错误，重试 {i + 1}/{retries}")
            time.sleep(3)
            continue
        raise RuntimeError(f"微信接口返回错误: {data}")
    raise RuntimeError(f"重试耗尽: {last}")


def main():
    if not APPID or not APPSECRET:
        raise SystemExit("缺少 MP_APPID / MP_APPSECRET 环境变量")

    tok = request("GET", f"{BASE}/token", params={
        "grant_type": "client_credential", "appid": APPID, "secret": APPSECRET,
    })
    token = tok["access_token"]
    print("✓ access_token 获取成功")

    content = BODY_FILE.read_text(encoding="utf-8")

    def upload_body_image(path):
        with open(path, "rb") as f:
            data = request("POST", f"{BASE}/media/uploadimg",
                           params={"access_token": token},
                           files={"media": (path.name, f, "image/png")})
        print(f"  ↑ 上传正文图 {path.name}")
        return data["url"]

    def repl(m):
        rel = m.group(1)
        return 'src="%s"' % upload_body_image(WORK_DIR / rel)

    content = re.sub(r'src="(assets/[^"]+)"', repl, content)

    thumb_path = ASSETS_DIR / THUMB_NAME
    with open(thumb_path, "rb") as f:
        mdata = request("POST", f"{BASE}/material/add_material",
                        params={"access_token": token, "type": "image"},
                        files={"media": (THUMB_NAME, f, "image/png")})
    thumb_media_id = mdata["media_id"]
    print(f"✓ 封面上传成功: {thumb_media_id}")

    payload = {"articles": [{
        "title": TITLE,
        "author": AUTHOR,
        "digest": DIGEST,
        "content": content,
        "content_source_url": "",
        "thumb_media_id": thumb_media_id,
        "need_open_comment": 0,
        "only_fans_can_comment": 0,
    }]}
    res = request("POST", f"{BASE}/draft/add",
                  params={"access_token": token},
                  data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                  headers={"Content-Type": "application/json"})
    print("✓ 草稿推送成功")
    print("media_id:", res.get("media_id"))


if __name__ == "__main__":
    main()
