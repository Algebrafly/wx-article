# -*- coding: utf-8 -*-
import json, os, re, sys, time
from pathlib import Path
import requests

WORK_DIR = Path(__file__).resolve().parent
BODY_FILE = WORK_DIR / "body.html"
ASSETS_DIR = WORK_DIR / "assets"

TITLE = "让每一次提问都命中公司内部最准的那一段：企业级知识库（RAG）实战"
AUTHOR = "TraeWork"
DIGEST = "参考业界开源 RAG 框架能力，演示仪表盘、知识源、对话检索、自动 Wiki、使用记录五块界面。为什么它不是 AI 玩具，是知识资产的统一出口。"
THUMB_NAME = "cover.png"

APPID = os.environ.get("MP_APPID", "")
APPSECRET = os.environ.get("MP_APPSECRET", "")
if not APPID or not APPSECRET:
    sys.exit("缺少 MP_APPID / MP_APPSECRET 环境变量")

BASE = "https://api.weixin.qq.com/cgi-bin"
TIMEOUT = 60


def request(method, url, retries=60, **kwargs):
    kwargs.setdefault("timeout", TIMEOUT)
    last = None
    for i in range(retries):
        try:
            resp = requests.request(method, url, **kwargs)
            data = resp.json()
        except Exception as exc:
            last = exc
            time.sleep(2); continue
        code = data.get("errcode", 0)
        if code in (0, None): return data
        if code == 40164:
            print(f"  40164 出口 IP 未加白，重试 {i + 1}")
            time.sleep(0.8); continue
        if code in (-1, 45009, 40001, 42001):
            print(f"  临时错误 {code}，重试 {i + 1}")
            time.sleep(3); continue
        raise RuntimeError(f"微信接口返回错误: {data}")
    raise RuntimeError(f"重试耗尽: {last}")


def get_token():
    data = request("GET", f"{BASE}/token",
                   params={"grant_type": "client_credential", "appid": APPID, "secret": APPSECRET})
    token = data.get("access_token")
    if not token: raise RuntimeError(f"未取得 access_token: {data}")
    return token


def upload_body_images(token, content):
    refs = sorted(set(re.findall(r'src="(assets/[^"]+)"', content)))
    for ref in refs:
        path = WORK_DIR / ref
        if not path.exists(): raise FileNotFoundError(f"图片缺失: {path}")
        with path.open("rb") as fh:
            data = request("POST", f"{BASE}/media/uploadimg",
                           params={"access_token": token},
                           files={"media": (path.name, fh)})
        url = data.get("url")
        if not url: raise RuntimeError(f"上传正文图失败: {path} -> {data}")
        content = content.replace(f'src="{ref}"', f'src="{url}"')
        print(f"  正文图 {ref} -> ok")
    return content


def upload_thumb(token):
    path = ASSETS_DIR / THUMB_NAME
    with path.open("rb") as fh:
        data = request("POST", f"{BASE}/material/add_material",
                       params={"access_token": token, "type": "image"},
                       files={"media": (path.name, fh)})
    media_id = data.get("media_id")
    if not media_id: raise RuntimeError(f"上传封面失败: {data}")
    print("  封面 -> ok")
    return media_id


def main():
    content = BODY_FILE.read_text(encoding="utf-8")
    token = get_token(); print("  access_token -> ok")
    content = upload_body_images(token, content)
    thumb_media_id = upload_thumb(token)

    payload = {"articles": [{
        "title": TITLE, "author": AUTHOR, "digest": DIGEST,
        "content": content, "content_source_url": "",
        "thumb_media_id": thumb_media_id,
        "need_open_comment": 0, "only_fans_can_comment": 0,
    }]}
    data = request("POST", f"{BASE}/draft/add",
                   params={"access_token": token},
                   data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                   headers={"Content-Type": "application/json; charset=utf-8"})
    media_id = data.get("media_id")
    if not media_id: raise RuntimeError(f"建草稿失败: {data}")
    print(f"✓ 草稿已创建 media_id={media_id}")


if __name__ == "__main__": main()
