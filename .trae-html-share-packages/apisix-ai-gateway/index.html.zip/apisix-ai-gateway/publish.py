#!/usr/bin/env python3
"""把 apisix-ai-gateway 推送到公众号草稿箱。

凭据从环境变量读取（不落盘、不入库）：
    export MP_APPID=xxx
    export MP_APPSECRET=yyy
    python3 publish.py
"""

import json
import os
import re
import sys
import time
from pathlib import Path

import requests

WORK_DIR = Path(__file__).resolve().parent
BODY_FILE = WORK_DIR / "body.html"
TITLE = "别让模型 Key 散落在四个服务里：APISIX 做 AI 网关"
AUTHOR = "TraeWork"
DIGEST = "装一遍、跑通一条 AI 路由，再讲多模型容灾、按 token 限流和语义路由。附三个必踩的坑：请求头透传、max_tokens 映射、流式状态码。"
THUMB_NAME = "cover.png"

APPID = os.environ.get("MP_APPID", "")
APPSECRET = os.environ.get("MP_APPSECRET", "")
BASE = "https://api.weixin.qq.com/cgi-bin"
TIMEOUT = 60


def request(method, url, retries=60, **kwargs):
    kwargs.setdefault("timeout", TIMEOUT)
    last = None
    for i in range(retries):
        try:
            resp = requests.request(method, url, **kwargs)
            data = resp.json()
        except Exception as exc:
            last = exc
            print(f"  ! 请求异常({i + 1}/{retries}): {exc}")
            time.sleep(2)
            continue
        code = data.get("errcode", 0)
        if code in (0, None):
            return data
        if code == 40164:
            last = data
            print(f"  ! 出口 IP 未命中白名单，重试({i + 1}/{retries})")
            time.sleep(0.8)
            continue
        if code in (-1, 45009, 40001, 42001):
            last = data
            print(f"  ! errcode={code} 重试({i + 1}/{retries})")
            time.sleep(3)
            continue
        raise RuntimeError(f"微信接口返回错误: {data}")
    raise RuntimeError(f"重试耗尽: {last}")


def get_token():
    data = request(
        "GET",
        f"{BASE}/token",
        params={"grant_type": "client_credential", "appid": APPID, "secret": APPSECRET},
    )
    token = data.get("access_token")
    if not token:
        raise RuntimeError(f"获取 access_token 失败: {data}")
    print("✓ access_token 获取成功")
    return token


def upload_body_image(token, path):
    mime = "image/png" if path.suffix.lower() == ".png" else "image/jpeg"
    with open(path, "rb") as fh:
        data = request(
            "POST",
            f"{BASE}/media/uploadimg",
            params={"access_token": token},
            files={"media": (path.name, fh, mime)},
        )
    url = data.get("url")
    if not url:
        raise RuntimeError(f"正文图片上传失败: {data}")
    return url


def upload_thumb(token, path):
    mime = "image/png" if path.suffix.lower() == ".png" else "image/jpeg"
    with open(path, "rb") as fh:
        data = request(
            "POST",
            f"{BASE}/material/add_material",
            params={"access_token": token, "type": "image"},
            files={"media": (path.name, fh, mime)},
        )
    mid = data.get("media_id")
    if not mid:
        raise RuntimeError(f"封面素材上传失败: {data}")
    return mid


def main():
    if not APPID or not APPSECRET:
        sys.exit("缺少环境变量 MP_APPID / MP_APPSECRET")
    if not BODY_FILE.exists():
        sys.exit(f"找不到正文文件: {BODY_FILE}")

    content = BODY_FILE.read_text(encoding="utf-8")
    token = get_token()

    images = sorted(set(re.findall(r'src="(assets/[^"]+)"', content)))
    print(f"发现 {len(images)} 张正文图片")
    for rel in images:
        local = WORK_DIR / rel
        if not local.exists():
            sys.exit(f"图片缺失: {local}")
        remote = upload_body_image(token, local)
        content = content.replace(f'src="{rel}"', f'src="{remote}"')
        print(f"  ✓ {local.name}")

    thumb_id = upload_thumb(token, WORK_DIR / "assets" / THUMB_NAME)
    print("✓ 封面上传完成")

    article = {
        "articles": [
            {
                "title": TITLE,
                "author": AUTHOR,
                "digest": DIGEST,
                "content": content,
                "content_source_url": "",
                "thumb_media_id": thumb_id,
                "need_open_comment": 0,
                "only_fans_can_comment": 0,
            }
        ]
    }
    result = request(
        "POST",
        f"{BASE}/draft/add",
        params={"access_token": token},
        data=json.dumps(article, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8"},
    )
    print(f"✓ 草稿已创建 media_id={result.get('media_id')}")


if __name__ == "__main__":
    main()
