#!/usr/bin/env python3
"""把 loopforge-guide 推送到公众号草稿箱。

凭据从环境变量读取（不落盘、不入库）：
    export MP_APPID=xxx
    export MP_APPSECRET=yyy
    python3 publish.py
"""

import json
import os
import re
import sys
import time
from pathlib import Path

import requests

WORK_DIR = Path(__file__).resolve().parent
BODY_FILE = WORK_DIR / "body.html"
TITLE = "LoopForge 上手：让 AI 按 SOP 交付，而不只是聊两句"
AUTHOR = "TraeWork"
DIGEST = "腾讯开源的团队级 AI 研发协作平台：三行命令部署、免 Key 跑通审核流程、9 种执行器配法、SOP 客观门禁与人工关卡，附七个踩坑。"
THUMB_NAME = "home.png"

APPID = os.environ.get("MP_APPID", "")
APPSECRET = os.environ.get("MP_APPSECRET", "")
BASE = "https://api.weixin.qq.com/cgi-bin"
TIMEOUT = 60


def request(method, url, retries=60, **kwargs):
    kwargs.setdefault("timeout", TIMEOUT)
    last = None
    for i in range(retries):
        try:
            resp = requests.request(method, url, **kwargs)
            data = resp.json()
        except Exception as exc:  # 网络抖动 / 代理超时
            last = exc
            print(f"  ! 请求异常({i + 1}/{retries}): {exc}")
            time.sleep(2)
            continue
        code = data.get("errcode", 0)
        if code in (0, None):
            return data
        if code in (-1, 45009, 40001, 42001):  # 系统繁忙 / 限流 / token 失效
            last = data
            print(f"  ! errcode={code} {data.get('errmsg')} 重试({i + 1}/{retries})")
            time.sleep(3)
            continue
        raise RuntimeError(f"微信接口返回错误: {data}")
    raise RuntimeError(f"重试耗尽: {last}")


def get_token():
    data = request(
        "GET",
        f"{BASE}/token",
        params={"grant_type": "client_credential", "appid": APPID, "secret": APPSECRET},
    )
    token = data.get("access_token")
    if not token:
        raise RuntimeError(f"获取 access_token 失败: {data}")
    print(f"✓ access_token 获取成功（有效期 {data.get('expires_in')} 秒）")
    return token


def upload_body_image(token, path):
    with open(path, "rb") as fh:
        data = request(
            "POST",
            f"{BASE}/media/uploadimg",
            params={"access_token": token},
            files={"media": (path.name, fh, "image/png")},
        )
    url = data.get("url")
    if not url:
        raise RuntimeError(f"正文图片上传失败: {data}")
    return url


def upload_thumb(token, path):
    with open(path, "rb") as fh:
        data = request(
            "POST",
            f"{BASE}/material/add_material",
            params={"access_token": token, "type": "image"},
            files={"media": (path.name, fh, "image/png")},
        )
    mid = data.get("media_id")
    if not mid:
        raise RuntimeError(f"封面素材上传失败: {data}")
    return mid


def main():
    if not APPID or not APPSECRET:
        sys.exit("缺少环境变量 MP_APPID / MP_APPSECRET")
    if not BODY_FILE.exists():
        sys.exit(f"找不到正文文件: {BODY_FILE}")

    content = BODY_FILE.read_text(encoding="utf-8")
    token = get_token()

    # 正文图片：本地路径 -> 微信图床 URL
    images = sorted(set(re.findall(r'src="(assets/[^"]+)"', content)))
    print(f"发现 {len(images)} 张正文图片")
    for rel in images:
        local = WORK_DIR / rel
        if not local.exists():
            sys.exit(f"图片缺失: {local}")
        remote = upload_body_image(token, local)
        content = content.replace(f'src="{rel}"', f'src="{remote}"')
        print(f"  ✓ {local.name} -> {remote[:60]}...")

    thumb_path = WORK_DIR / "assets" / THUMB_NAME
    thumb_id = upload_thumb(token, thumb_path)
    print(f"✓ 封面上传完成 media_id={thumb_id[:20]}...")

    article = {
        "articles": [
            {
                "title": TITLE,
                "author": AUTHOR,
                "digest": DIGEST,
                "content": content,
                "content_source_url": "",
                "thumb_media_id": thumb_id,
                "need_open_comment": 0,
                "only_fans_can_comment": 0,
            }
        ]
    }
    result = request(
        "POST",
        f"{BASE}/draft/add",
        params={"access_token": token},
        data=json.dumps(article, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8"},
    )
    print(f"✓ 草稿已创建 media_id={result.get('media_id')}")


if __name__ == "__main__":
    main()
